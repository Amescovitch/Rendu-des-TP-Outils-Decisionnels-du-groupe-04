GROUPE 07:

1. AYANOU Tountoun Abel

2. NAYO Komi Phillipe

3. YOVO Amèvi